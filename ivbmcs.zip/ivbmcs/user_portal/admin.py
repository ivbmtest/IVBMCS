from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Free_consult_detail)
admin.site.register(userdata)
admin.site.register(user_service_details)
admin.site.register(user_notification)